@extends('layouts.app')

@section('content')
<div class="container text-center mt-5">
    <h1 class="text-danger">Kosong</h1>
    <p>Halaman atau tampilan yang Anda cari tidak tersedia.</p>
</div>
@endsection
